from ops import *
from ai_opt_param import getAIOptParam
import config_isp
import random
import numpy as np
import datetime
import params_dict as params_dict_isp

class ParamProcessCamb():
    def __init__(self):
        super(ParamProcessCamb, self).__init__()
        self.args = config_isp.parse_args()
        
    def getAIManualXml(self, is_save=True, ai_predict_param=None, save_xml_path=None):
        self.args.ai_predict_param = ai_predict_param if ai_predict_param is not None else self.args.ai_predict_param[str(args.gain)+'dB']
        param_dict = params_dict_isp.getParamsDict()
        param_info = params_dict_isp.getParamInfoDict()  # 获取ISP特殊参数信息
        param_dict_manual = params_dict_isp.getParamsManualDict()
        # error_node = [] # 寒武纪更新版本取消部分参数接口

        # 从Fae提供的xml获得初始参数
        param_dict_merge = mergeParamDict(param_dict)
        param_info_merge = mergeParamDict(param_info)
        init_param_value_list = getInitParamsValue(self.args.init_xml_file, self.args.gain, param_dict_merge)
        
        param_dict_opt = getOptParamDict(param_dict, self.args.opt_module)
        param_dict_unfold, _ = unfoldParamDict(param_dict)
        param_dict_opt_unfold, _ = unfoldParamDict(param_dict_opt)
        param_info_unfold, _ = unfoldParamDict(param_info)  # 展开参数列表
        param_dict_opt_unfold = updateOptParamDict(param_dict_opt_unfold, param_info_unfold)

        predict_param = mergeParam(self.args.ai_predict_param, init_param_value_list, param_dict_opt_unfold, param_dict_unfold, param_info_unfold)
        predict_param = changeStrParamValue(predict_param, param_dict_unfold, param_info_unfold)

        print(self.args.gain,'dB, ', predict_param, ', Length:', len(predict_param))
        # print(predict_param)
        tree = read_xml(self.args.base_xml_file)
        nodes = find_nodes(tree, "DEFINITIONS/STRUCT_DEF/STRUCT/MEMBER")

        index = 0
        is_tdnr = False
        info = None
        print('---------------------------------------------------------------------------------')
        predict_param_transInfo_list = []
        for isp_param_name in param_dict_merge.keys():
            isp_param_name_auto = isp_param_name
            is_tdnr = False if isp_param_name.split('.')[0] != 'cnviTdnrAutoAttr_t' else True
            info = isUseInfo(isp_param_name, param_info_merge)

            if isp_param_name in param_dict_manual.keys():
                isp_param_name = param_dict_manual[isp_param_name]
            if isp_param_name is None:
                predict_param_transInfo_list.append(predict_param[index])
                index += 1
                continue

            isp_param_name_manual = isp_param_name.replace('Auto', 'Manual')
            isp_param_name_raw = isp_param_name_manual.split('/')[0]
            result_nodes = get_node_by_keyvalue(nodes, {'TYPE': isp_param_name_raw.split('.')[0]}) if not is_tdnr else get_node_by_keyvalue(nodes, {'TYPE': isp_param_name_raw.split('.')[0], 'ALIAS': "TdnrManualAttr"})
            if len(result_nodes)==0: result_nodes = get_node_by_keyvalue(nodes, {'ID': isp_param_name_raw.split('.')[0]})
            if len(result_nodes)!=1 :
                # index += 1
                # error_node.append(isp_param_name)
                # continue
                raise Exception(isp_param_name+' 节点错误!')

            isp_param_name_raw_list = isp_param_name_raw.split('.')

            if len(isp_param_name_raw_list) != 1:
                for name in isp_param_name_raw_list[1:]:
                    result_nodes = find_nodes(result_nodes[0], name)

            if len(result_nodes)!=1 : raise Exception(isp_param_name+' 节点错误!')
            if '/' not in isp_param_name:
                param_value = init_param_value_list[index]
                new_param_value = predict_param[index]
                new_param_value = transferParamValue(new_param_value, info, param_dict_merge[isp_param_name_auto])[0] if info is not None else new_param_value
                predict_param_transInfo_list.append(new_param_value)

                result_nodes[0].text = str(new_param_value)
                index += 1
                print('%s: %d -> %d'%(isp_param_name_manual, param_value, new_param_value))
            else:
                if '_' in isp_param_name.split('/')[-1]:
                    tmp = isp_param_name.split('/')[-1]
                    param_value_list = init_param_value_list[index:index+int(tmp.split('_')[1])-int(tmp.split('_')[0])]
                    new_param_value_list = predict_param[index: index+int(tmp.split('_')[1])-int(tmp.split('_')[0])]

                    new_param_value_list_ = new_param_value_list.copy()
                    new_param_value_list = transferParamValue(new_param_value_list, info, param_dict_merge[isp_param_name_auto]) if info is not None else new_param_value_list
                    
                    if info[0] == 'Curve':
                        predict_param_transInfo_list += new_param_value_list_
                    else:
                        predict_param_transInfo_list += new_param_value_list

                    s_index = int(tmp.split('_')[0])
                    tmp_str = result_nodes[0].text.split(',')
                    tmp_str = [int(x) for x in tmp_str]
                    tmp_str[s_index:s_index+len(new_param_value_list)] = new_param_value_list

                    result_nodes[0].text = str(tmp_str)[1:-1]
                    index += (int(tmp.split('_')[1])-int(tmp.split('_')[0]))
                else:
                    param_value_list = init_param_value_list[index:index+int(isp_param_name.split('/')[-1])]
                    new_param_value_list = predict_param[index: index+int(isp_param_name.split('/')[-1])]
                    new_param_value_list = transferParamValue(new_param_value_list, info, param_dict_merge[isp_param_name_auto]) if info is not None else new_param_value_list
                    predict_param_transInfo_list += new_param_value_list

                    result_nodes[0].text = str(new_param_value_list)[1:-1]
                    index += int(isp_param_name.split('/')[-1])
                print('%s: %s -> %s'%(isp_param_name_manual, str(param_value_list), str(new_param_value_list)))

        print('---------------------------------------------------------------------------------')
        if len(predict_param_transInfo_list) == len(predict_param):
            for i in range(len(predict_param_transInfo_list)):
                if predict_param[i] != predict_param_transInfo_list[i]:
                    print(list(param_dict_unfold.keys())[i],': ', predict_param[i], '--->', predict_param_transInfo_list[i])
            print('AI opt params: ', predict_param_transInfo_list)
            print('Len: ', len(predict_param_transInfo_list))
        else:
            raise  Exception('参数数量错误!')

        if index != len(predict_param):
            raise  Exception('参数数量错误!')

        if is_save:
            # checkFolder(self.args.save_xml_file)
            # cur_time = datetime.datetime.now()
            # save_xml_file = os.path.join(self.args.save_xml_file, 'AI_'+str(self.args.gain)+'dB_'+self.args.opt_module+'_'+self.args.vipe+'_'+str(cur_time.year)+str(cur_time.month).zfill(2)+str(cur_time.day).zfill(2)+str(cur_time.hour).zfill(2)+str(cur_time.minute).zfill(2)+str(cur_time.second).zfill(2)+'.xml')
            if save_xml_path is not None:
                write_xml(tree, save_xml_path)
            else:
                write_xml(tree, self.args.save_xml_file)
        
        # print("寒武纪更新版本取消的接口：", set(error_node))
        print("Done!")
        return predict_param_transInfo_list
    
    def getDataCollectTxt(self):
        param_dict = params_dict_isp.getParamsDict()   # 获取ISP参数列表
        param_info = params_dict_isp.getParamInfoDict()  # 获取ISP特殊参数信息
        
        vipe = self.args.vipe # 全景:panoramic | 特写: close
        sample_nums = 10000  # 采样参数样本数量
        data_collect_gain = self.args.data_collect_gain          # 增益
        # Linear
        # margin_ratio = {'DRC':0.1, 'Contrast_Demosaic_BNR_PreSharpen_PreSNR_PreTNRS_PreTNRT_PostTNR_PostSNR_PostSharpen': 0.1} # 初始值参数采样范围
        # DCG
        margin_ratio = {'DRC':0.5, 'Contrast_Demosaic_BNR_PreSharpen_PreSNR_PreTNRS_PreTNRT_PostTNR_PostSNR_PostSharpen': 0.1} # 初始值参数采样范围
        margin_max = 65535    # 最大采样间距
        margin_min = 8      # 最小采样间距
        opt_iter = 1        # 迭代轮次
        param_loop = 1      # 每个参数重复采样次数
        data_collect_module = self.args.data_collect_module # 优化模块 Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PostSNR_PreTNR_PostTNR
        cur_time = datetime.datetime.now()  # 当前时间

        txt_save_path_all = os.path.join(self.args.save_txt_path, self.args.soc_id, 'Dataset', self.args.device_id, 'data_collect', vipe, str(data_collect_gain)+'dB')
        checkFolder(txt_save_path_all)
        txt_save_path_all = os.path.join(txt_save_path_all, 'camb_proxyopt_sample_%d_%sdB_%s_opt%d_paramLoop%d_%s_%s_%s.txt'%\
            (sample_nums, str(data_collect_gain), data_collect_module, opt_iter, param_loop, vipe, str(cur_time.year)+str(cur_time.month).zfill(2)+str(cur_time.day).zfill(2), str(cur_time.hour).zfill(2)+str(cur_time.minute).zfill(2)+str(cur_time.second).zfill(2)))
        param_save_path_all = txt_save_path_all[:-4] + '.py'            # 优化模块参数列表保存路径
        param_all_save_path_all = param_save_path_all[:-3] + '_all.py'
        is_first = True
        is_last = False
        for gain in data_collect_gain:
            setSeed(0)  # 设置随机数种子
            txt_save_path = os.path.join(self.args.save_txt_path, self.args.soc_id, 'Dataset', self.args.device_id, 'data_collect', vipe, str(gain)+'dB')
            checkFolder(txt_save_path)
            txt_save_path = os.path.join(txt_save_path, 'camb_proxyopt_sample_%d_%ddB_%s_opt%d_paramLoop%d_%s_%s_%s.txt'%\
                (sample_nums, gain, data_collect_module, opt_iter, param_loop, vipe, str(cur_time.year)+str(cur_time.month).zfill(2)+str(cur_time.day).zfill(2), str(cur_time.hour).zfill(2)+str(cur_time.minute).zfill(2)+str(cur_time.second).zfill(2)))
            param_save_path = txt_save_path[:-4] + '.py'            # 优化模块参数列表保存路径
            param_all_save_path = param_save_path[:-3] + '_all.py'  # 所有模块参数列表保存路径
            # Fae | ISP参数xml路径 Fae_20210903_IPC2233_FN_SIR40_Z2712_Ver_D_Dummy_HDR | IPC2233_FN_SIR40_Z2712_Ver_D_HDR
            init_xml_file = self.args.init_xml_file

            # 从Fae提供的xml获得初始参数
            param_dict_merge = mergeParamDict(param_dict)
            init_param_value_list = getInitParamsValue(init_xml_file, gain, param_dict_merge)
            # 自定义初始参数
            if self.args.is_self_init:
                init_param_value_list = self.getAIManualXml(ai_predict_param=self.args.ai_init_param[str(gain)+'dB'])
            print(gain,'dB, Init param value:', init_param_value_list, ', Length:', len(init_param_value_list))
            
            param_dict_opt = getOptParamDict(param_dict, data_collect_module)
            param_dict_unfold, _ = unfoldParamDict(param_dict)
            param_info_unfold, _ = unfoldParamDict(param_info)  # 展开参数列表
            param_dict_opt_unfold, module_info = unfoldParamDict(param_dict_opt)  # 展开参数列表

            if len(param_dict_unfold) != len(init_param_value_list):
                print('The length of param_dict:', len(param_dict_unfold))
                print('The length of init_param_value_list:', len(init_param_value_list))
                raise Exception('参数列表与初始化参数 数量 不匹配!')
            
            init_param_value_list = transferInitParam(init_param_value_list, param_dict_unfold, param_info_unfold)
            param_dict_unfold, param_dict_opt_unfold = updateParamDictInitValue(param_dict_unfold, init_param_value_list, param_dict_opt_unfold)
            param_dict_opt_unfold = updateOptParamDict(param_dict_opt_unfold, param_info_unfold)
            
            param_dict_opt_unfold_update = getOptParamSampleRange(param_dict_opt_unfold, margin_ratio, margin_max, margin_min, module_info) # 得到参数采样范围
            sample_result, param_dict_opt_unfold_update = randomSample(param_dict_opt_unfold_update, sample_nums, param_info_unfold)    # 随机采样

            # writeSampleTxt(param_dict_opt_unfold_update, param_dict_unfold, sample_result.copy(), init_param_value_list.copy(), txt_save_path, param_loop)
            # writeSampleCollectTxt(param_dict_opt_unfold_update, param_dict_unfold, param_info_unfold, sample_result.copy(), init_param_value_list.copy(), txt_save_path[:-4]+'_collect.txt', param_loop, gain)
            if gain == data_collect_gain[-1]:
                is_last = True
            writeOptParamDict(param_dict_opt_unfold_update, param_save_path_all, gain, is_first, is_last)
            writeAllParamsDict(param_dict_unfold, param_all_save_path_all, gain, is_first, is_last)
            writeSampleTxt(param_dict_opt_unfold_update, param_dict_unfold, sample_result.copy(), init_param_value_list.copy(), txt_save_path_all, param_loop)
            writeSampleCollectTxt(param_dict_opt_unfold_update, param_dict_unfold, param_info_unfold, sample_result.copy(), init_param_value_list.copy(), txt_save_path_all[:-4]+'_collect.txt', param_loop, gain)
            is_first = False

        with open(txt_save_path_all[:-4]+'_collect.txt', 'a') as f:
            f.write('\n')
        print('Done!')

    def getISPCFile(self):
        param_type = self.args.param_type_C
        # AI优化参数
        device_id = '_'.join([self.args.device_id, self.args.vipe, param_type])
        ai_params, gain_list, gain_opt_module = getAIOptParam(device_id=device_id)

        # ISP参数范围
        param_dict = params_dict_isp.getParamsDict()
        param_info = params_dict_isp.getParamInfoDict()
        param_dict_c = params_dict_isp.getParamDictC()

        param_dict_merge = mergeParamDict(param_dict)
        param_info_merge = mergeParamDict(param_info)
        param_dict_unfold, _ = unfoldParamDict(param_dict)
        param_info_unfold, _ = unfoldParamDict(param_info)

        isp_c_file = readISPCFile(self.args.base_c_file)

        for gain in gain_list:
            param_dict_opt = getOptParamDict(param_dict, gain_opt_module[str(gain)+'dB'])
            param_dict_opt_unfold, _= unfoldParamDict(param_dict_opt)
            param_dict_opt_unfold = updateOptParamDict(param_dict_opt_unfold, param_info_unfold)

            index = 0
            if str(gain)+'dB' not in ai_params.keys():
                continue
            init_param_value_list = getInitParamsValue(self.args.init_xml_file, gain, param_dict_merge)
            ai_param_value = ai_params[str(gain)+'dB']
            ai_param_value = mergeParam(ai_param_value, init_param_value_list, param_dict_opt_unfold, param_dict_unfold, param_info_unfold)
            predict_param = changeStrParamValue(ai_param_value, param_dict_unfold, param_info_unfold)

            for isp_param_name in param_dict_merge.keys():
                info = isUseInfo(isp_param_name, param_info_merge)
                if isp_param_name not in param_dict_c.keys():
                    raise Exception(isp_param_name+' not in param_dict_c!')

                isp_param_name_c = param_dict_c[isp_param_name]
                if param_type == 'Car' and isp_param_name_c is not None: isp_param_name_c += '_car'
                if param_type == 'DCG' and isp_param_name_c is not None: isp_param_name_c += '_DCG'
                if isp_param_name_c is None:
                    if '/' not in isp_param_name:
                        index += 1
                    else:
                        if '_' in isp_param_name.split('/')[-1]:
                            index += int(isp_param_name.split('/')[-1].split('_')[1])-int(isp_param_name.split('/')[-1].split('_')[0])
                        else:
                            index += int(isp_param_name.split('/')[-1])
                    continue

                isp_param_name_c_line, line_index = findISPCParam(isp_param_name_c, isp_c_file, param_type)
                if isp_param_name_c_line is None:
                    raise Exception(isp_param_name, '->', isp_param_name_c , '参数未找到!')

                # print(isp_param_name_c_line)
                if '/' not in isp_param_name:
                    new_param_value = predict_param[index]
                    new_param_value = transferParamValue(new_param_value, info, param_dict_merge[isp_param_name])[0] if info is not None else new_param_value

                    isp_param_name_c_line_var = isp_param_name_c_line.split('=')[0]
                    if '[' in isp_param_name_c_line_var and int(isp_param_name_c_line_var.split('[')[-1].split(']')[0]) == 2:
                        line_index = line_index+1+gain//6
                        isp_param_name_c_line = isp_c_file[line_index]
                        isp_param_name_c_line_var = isp_param_name_c_line.split('{')[0]
                        isp_param_name_c_line_val = isp_param_name_c_line.split('{')[-1].split('}')[0].replace(' ', '').split(',')
                        isp_param_name_c_line_val[1] = new_param_value

                        # isp_param_name_c_line_val[gain//6] = str(new_param_value)
                        isp_param_name_c_line_val = transValListToStr(isp_param_name_c_line_val)

                        isp_c_file[line_index] = isp_param_name_c_line_var+'{'+isp_param_name_c_line_val+'},\n'
                    else:
                        isp_param_name_c_line_val = isp_param_name_c_line.split('=')[-1].split('{')[-1].split('}')[0].split(',')
                        isp_param_name_c_line_val[gain//6] = str(new_param_value)
                        isp_param_name_c_line_val = transValListToStr(isp_param_name_c_line_val)

                        isp_c_file[line_index] = isp_param_name_c_line_var+'={'+isp_param_name_c_line_val+'};\n'

                    index += 1
                else:
                    if '_' in isp_param_name.split('/')[-1]:
                        tmp = isp_param_name.split('/')[-1]
                        new_param_value_list = predict_param[index: index+int(tmp.split('_')[1])-int(tmp.split('_')[0])]

                        new_param_value_list_ = new_param_value_list.copy()
                        new_param_value_list = transferParamValue(new_param_value_list, info, param_dict_merge[isp_param_name]) if info is not None else new_param_value_list

                        line_index = line_index+1+gain//6
                        isp_param_name_c_line = isp_c_file[line_index]
                        isp_param_name_c_line_var = isp_param_name_c_line.split('{')[0]
                        isp_param_name_c_line_val = isp_param_name_c_line.split('{')[-1].split('}')[0]
                        # isp_param_name_c_line_val[gain//6] = str(new_param_value)
                        isp_param_name_c_line_val = transValListToStr(new_param_value_list)

                        isp_c_file[line_index] = isp_param_name_c_line_var+'{'+isp_param_name_c_line_val+'},\n'

                        index += (int(tmp.split('_')[1])-int(tmp.split('_')[0]))
                    else:
                        new_param_value_list = predict_param[index: index+int(isp_param_name.split('/')[-1])]
                        new_param_value_list = transferParamValue(new_param_value_list, info, param_dict_merge[isp_param_name]) if info is not None else new_param_value_list

                        array_rows = 0
                        if isp_c_file[line_index].count('[') == 3:
                            array_rows = int(isp_c_file[line_index].split('[')[2].split(']')[0])

                        line_index = line_index+1+gain//6
                        isp_param_name_c_line = isp_c_file[line_index]
                        isp_param_name_c_line_var = isp_param_name_c_line.split('{')[0]
                        isp_param_name_c_line_val = isp_param_name_c_line.split('{')[-1].split('}')[0]
                        # isp_param_name_c_line_val[gain//6] = str(new_param_value)
                        
                        if array_rows:
                            array_cols = len(new_param_value_list)//array_rows
                            isp_c_file[line_index] = isp_param_name_c_line_var+'{'
                            for m in range(array_rows-1):
                                isp_c_file[line_index] += '{'+transValListToStr(new_param_value_list[m*array_cols:(m+1)*array_cols])+'},'
                            isp_c_file[line_index] += '{'+transValListToStr(new_param_value_list[-array_cols:])+'}},\n'
                        else:
                            isp_param_name_c_line_val = transValListToStr(new_param_value_list)
                            isp_c_file[line_index] = isp_param_name_c_line_var+'{'+isp_param_name_c_line_val+'},\n'
                        index += int(isp_param_name.split('/')[-1])

            if index != len(ai_param_value):
                raise Exception(str(gain)+'dB'+'参数数量错误!')

        # checkFolder(self.args.save_c_file)
        writeISPCFile(isp_c_file, self.args.save_c_file)
        print('Done!')

    def getAIAutoXml(self):
        param_type = self.args.param_type
        # AI优化参数
        device_id = '_'.join([self.args.device_id, self.args.vipe, param_type])
        ai_params, gain_list, gain_opt_module = getAIOptParam(device_id=device_id)
        param_dict_manual = params_dict_isp.getParamsManualDict()

        # ISP参数范围
        param_dict = params_dict_isp.getParamsDict()
        param_info = params_dict_isp.getParamInfoDict()

        param_dict_merge = mergeParamDict(param_dict)
        param_info_merge = mergeParamDict(param_info)
        param_dict_unfold, _ = unfoldParamDict(param_dict)
        param_info_unfold, _ = unfoldParamDict(param_info)

        tree = read_xml(self.args.base_xml_auto_file)
        nodes = find_nodes(tree, "DEFINITIONS/STRUCT_DEF/STRUCT/MEMBER")

        for gain in gain_list:
            param_dict_opt = getOptParamDict(param_dict, gain_opt_module[str(gain)+'dB'])
            param_dict_opt_unfold, _ = unfoldParamDict(param_dict_opt)
            param_dict_opt_unfold = updateOptParamDict(param_dict_opt_unfold, param_info_unfold)

            index = 0
            gain_index = int(gain // 6)
            if str(gain)+'dB' not in ai_params.keys():
                continue
            init_param_value_list = getInitParamsValue(self.args.init_xml_file, gain, param_dict_merge)
            ai_param_value = ai_params[str(gain)+'dB']
            ai_param_value = mergeParam(ai_param_value, init_param_value_list, param_dict_opt_unfold, param_dict_unfold, param_info_unfold)
            ai_param_value = changeStrParamValue(ai_param_value, param_dict_unfold, param_info_unfold)

            for isp_param_name in param_dict_merge.keys():
                if isp_param_name in param_dict_manual.keys():
                    isp_param_name = param_dict_manual[isp_param_name]
                if isp_param_name is None:
                    index += 1
                    continue

                isp_param_name_auto = isp_param_name
                is_tdnr = False if isp_param_name.split('.')[0] != 'cnviTdnrAutoAttr_t' else True
                info = isUseInfo(isp_param_name, param_info_merge)

                isp_param_name_raw = isp_param_name.split('/')[0]
                result_nodes = get_node_by_keyvalue(nodes, {'TYPE': isp_param_name_raw.split('.')[0]}) 
                if len(result_nodes)==0: result_nodes = get_node_by_keyvalue(nodes, {'ID': isp_param_name_raw.split('.')[0]})
                if len(result_nodes)!=1 : raise Exception(isp_param_name+' 节点错误!')

                isp_param_name_raw_list = isp_param_name_raw.split('.')

                if is_tdnr:
                    isp_param_name_raw_list.insert(1, 'stTdnrParam')
                    isp_param_name_raw_list.insert(2, 'ARRITEM')

                if len(isp_param_name_raw_list) != 1:
                    for name in isp_param_name_raw_list[1:-1]:
                        if len(result_nodes) > 1 and is_tdnr:
                            result_nodes = find_nodes(result_nodes[gain_index], name)
                        else:
                            result_nodes = find_nodes(result_nodes[0], name)

                    result_nodes = find_nodes(result_nodes[0], isp_param_name_raw_list[-1])

                if len(result_nodes)!=1 : raise Exception(isp_param_name+' 节点错误!')
                COUNT = [] if 'COUNT' not in result_nodes[0].attrib else [int(x) for x in result_nodes[0].attrib['COUNT'].split(',')]

                if '/' not in isp_param_name:
                    param_value = ai_param_value[index]
                    param_value = transferParamValue(param_value, info, param_dict_merge[isp_param_name_auto])[0] if info is not None else param_value
                    isp_param_value = result_nodes[0].text.split(',')
                    if is_tdnr:
                        result_nodes[0].text = str(param_value)
                    else:
                        if len(COUNT) == 2 and COUNT[1] == 2:
                            try:
                                isp_param_value[gain_index*2+1] = str(param_value)
                            except:
                                isp_param_value[gain_index*0+1] = str(param_value)
                            result_nodes[0].text = str([int(x) for x in isp_param_value])[1:-1]
                        else:
                            result_nodes[0].text = str(param_value)
                            print(isp_param_name + ' COUNT不等于2!')
                    index += 1
                else:
                    if '_' in isp_param_name.split('/')[-1]:
                        tmp = isp_param_name.split('/')[-1]
                        new_param_value_list = ai_param_value[index: index+int(tmp.split('_')[1])-int(tmp.split('_')[0])]
                        new_param_value_list = transferParamValue(new_param_value_list, info, param_dict_merge[isp_param_name_auto]) if info is not None else new_param_value_list

                        s_index = int(tmp.split('_')[0])
                        tmp_str = result_nodes[0].text.split(',')
                        tmp_str = [int(x) for x in tmp_str]
                        tmp_str[s_index:s_index+len(new_param_value_list)] = new_param_value_list

                        result_nodes[0].text = str(tmp_str)[1:-1]
                        index += (int(tmp.split('_')[1])-int(tmp.split('_')[0]))
                    else:
                        new_param_value_list = ai_param_value[index: index+int(isp_param_name.split('/')[-1])]
                        new_param_value_list = transferParamValue(new_param_value_list, info, param_dict_merge[isp_param_name_auto]) if info is not None else new_param_value_list

                        result_nodes[0].text = str(new_param_value_list)[1:-1]
                        index += int(isp_param_name.split('/')[-1])

            if index != len(ai_param_value):
                raise Exception(str(gain)+'db'+'参数数量错误!')
                
        # checkFolder(self.args.save_xml_auto_file)
        write_xml(tree, self.args.save_xml_auto_file)
        print('Done!')

if __name__ == '__main__':
    aiProcess = ParamProcessCamb()
    args = config_isp.parse_args()
    if args.gen_xml_manual_file:
        aiProcess.getAIManualXml()
    if args.get_data_collect_txt:
        aiProcess.getDataCollectTxt()
    if args.get_isp_c_file:
        aiProcess.getISPCFile()
    if args.gen_xml_auto_file:
        aiProcess.getAIAutoXml()