def getAIOptParam(device_id):
    gain_list = {
        'IPC2856_Di7N_close_Person': [0,6,12,18,24,30],
        'IPC2856_Di7N_close_Car': [0,6,12,18,24,30],
        'IPC2856_Di7N_close_DCG': [0,6,12,18],
    }
    gain_opt_module = {
        'IPC2856_Di7N_close_Person': {
            '0dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRS_PreTNRT',
            '6dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '12dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '18dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '24dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '30dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '36dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
        },
        'IPC2856_Di7N_close_Car': {
            '0dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRS_PreTNRT',
            '6dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '12dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '18dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '24dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '30dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
            '36dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PreTNRT',
        },
        'IPC2856_Di7N_close_DCG': {
            '0dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PreTNRT',
            '6dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PreTNRT',
            '12dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PreTNRT',
            '18dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PreTNRT',
            # '24dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PreTNRT',
            # '30dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PreTNRT',
            # '36dB': 'Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PreTNRT',
        },
    }

    ai_opt_param = {
        'IPC2856-Di7N_Person': {
            '0dB': 
            [
                
            ],

            '6dB': 
            [
                
            ],
        },

    }
    return ai_opt_param[device_id], gain_list[device_id], gain_opt_module[device_id]