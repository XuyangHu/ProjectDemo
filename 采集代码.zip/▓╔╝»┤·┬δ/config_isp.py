# ISP config
import argparse
import os

def parse_args():
    parser = argparse.ArgumentParser(description='isp arguments')
    # 通用设置
    parser.add_argument('--soc_id', type=str, default='Cambricon', help='平台ID')
    parser.add_argument('--device_id', type=str, default='IPC2856_Di7N', help='设备ID')
    parser.add_argument('--gain', type=int, default=18, help='增益,可设0|6|12 ...')
    parser.add_argument('--vipe', type=str, default='close', help='双目pipe,特写端:close,全景:pano')
    parser.add_argument('--opt_module', type=str, default='', help='优化模块,可设Contrast_Demosaic_DRC_BNR_PreSharpen_PreSNR_PostSNR_PreTNR_PostTNR_PostSharpen')
    parser.add_argument('--init_xml_file', type=str, default='./Fae_IPC2856_Di7N_close_20221026_manual.xml', help='加载初始参数的xml路径')
    parser.add_argument('--ai_predict_param', type=int, default=ai_predict_param, help='AI已优化的超参数')
    parser.add_argument('--ai_init_param', type=int, default=ai_init_param, help='AI已优化的超参数')
    
    # 生成手动xml文件功能
    parser.add_argument('--gen_xml_manual_file', type=bool, default=False, help='是否生成手动xml文件')
    parser.add_argument('--base_xml_file', type=str, default='', help='基于Fae的xml路径')
    parser.add_argument('--save_xml_file', type=str, default='', help='保存xml路径')

    # 生成自动xml文件功能
    parser.add_argument('--gen_xml_auto_file', type=bool, default=False, help='是否生成自动xml文件')
    parser.add_argument('--param_type', type=str, default='DCG', help='参数类型,如车卡:Car | 人卡:Person | 宽动态:DCG')
    parser.add_argument('--base_xml_auto_file', type=str, default='.\Fae_IPC2856_Di7N_close_hdr_20230307_manual.xml', help='基于Fae的xml路径')
    parser.add_argument('--save_xml_auto_file', type=str, default='', help='保存xml路径')
   
    # 生成采集txt文件功能
    parser.add_argument('--get_data_collect_txt', type=bool, default=True, help='是否生成采集txt文件')
    parser.add_argument('--data_collect_gain', type=int, default=[0, 18], help='采集增益')
    parser.add_argument('--data_collect_module', type=str, default='Contrast_Demosaic_DRC_BNR_PreSharpen', help='优化模块,可设Contrast_Demosaic_DRC_BNR_PreSharpen_PostSharpen_PreSNR_PostSNR_PreTNR_PostTNR')
    parser.add_argument('--save_txt_path', type=str, default='./', help='保存采集txt的路径')
    parser.add_argument('--is_self_init', type=bool, default=False, help='是否自定义初始化')

    # 生成isp c文件功能, 目前仅支持自动化2856参数的填写，且base_c_file需按照规定编写
    parser.add_argument('--get_isp_c_file', type=bool, default=False, help='是否生成isp c文件')
    parser.add_argument('--param_type_C', type=str, default='DCG', help='参数类型,如车卡:Car | 人卡:Person | 宽动态:DCG')
    parser.add_argument('--save_c_file', type=str, default='', help='保存ai c文件的xml路径')
    parser.add_argument('--base_c_file', type=str, default='', help='基于isp c文件的xml路径')

    args = parser.parse_args()
    return args

ai_predict_param = {
    '0dB': [
    ],
}

ai_init_param = {
    '0dB': [
    ],
}