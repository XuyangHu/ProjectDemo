import random
from re import X
from cv2 import INTER_MAX
import numpy as np
import os
import shutil
from xml.etree.ElementTree import ElementTree, Element

def setSeed(seed=0):
    np.random.seed(seed)
    random.seed(seed)

def checkFolder(path, reset=False):
    if not os.path.exists(path):
        os.makedirs(path)
    elif reset == True:
        shutil.rmtree(path)
        os.makedirs(path)

def getOptParamDict(param_dict, opt_module):
    param_dict_opt = {}
    # opt_module_unfold = opt_module.split('_')
    for module_name in list(param_dict.keys()):
        if module_name in opt_module:
            param_dict_opt[module_name] = param_dict[module_name]
    return param_dict_opt

def mergeParamDict(param_dict):
    param_dict_merge = {}
    for module_name in param_dict.keys():
        for isp_param_name in param_dict[module_name].keys():
                param_dict_merge[isp_param_name] = param_dict[module_name][isp_param_name].copy()
    return param_dict_merge

def unfoldParamDict(param_dict):
    param_dict_unfold = {}
    module_info = {}
    for module_name in param_dict.keys():
        for isp_param_name in param_dict[module_name].keys():
            if '/' in isp_param_name:
                if '_' in isp_param_name.split('/')[-1]:
                    tmp = isp_param_name.split('/')[-1]
                    for k in range(int(tmp.split('_')[0]), int(tmp.split('_')[1])):
                        param_dict_unfold[isp_param_name.split('/')[0]+'_'+str(k)] = param_dict[module_name][isp_param_name].copy()
                        module_info[isp_param_name.split('/')[0]+'_'+str(k)] = module_name
                else:
                    for k in range(int(isp_param_name.split('/')[-1])):
                        param_dict_unfold[isp_param_name.split('/')[0]+'_'+str(k)] = param_dict[module_name][isp_param_name].copy()
                        module_info[isp_param_name.split('/')[0]+'_'+str(k)] = module_name
            else:
                param_dict_unfold[isp_param_name] = param_dict[module_name][isp_param_name].copy()
                module_info[isp_param_name] = module_name
    return param_dict_unfold, module_info

def updateParamDictInitValue(param_dict, init_param, param_dict_opt):
    cnt = 0
    for isp_param_name in list(param_dict.keys()):
        param_dict[isp_param_name].insert(2, init_param[cnt])
        if isp_param_name in list(param_dict_opt.keys()):
            param_dict_opt[isp_param_name].insert(2, init_param[cnt])
        cnt += 1
    return param_dict, param_dict_opt

def updateOptParamDict(param_dict, param_info):
    for isp_param_name in list(param_dict.keys()):
        if isp_param_name in list(param_info.keys()) and param_info[isp_param_name][0] == 'Default':
            param_dict.pop(isp_param_name)
    return param_dict

def getSampleRatio(margin_ratio, module_name):
    for name in margin_ratio.keys():
        if module_name in name:
            return margin_ratio[name]
    raise Exception('opt module is not exist!')

def getOptParamSampleRange(param_dict, margin_ratio, margin_max=512, margin_min=4, module_info=None):
    cnt = 0
    param_dict_update_range = {}
    for isp_param_name in param_dict.keys():
        param_range = param_dict[isp_param_name]
        init_param_v = param_range[2]

        ratio = getSampleRatio(margin_ratio, module_info[isp_param_name])
        margin = int((param_range[1]-param_range[0]) * ratio)
        margin = min(margin, margin_max)
        margin = max(margin, margin_min)

        low_v = init_param_v - margin
        low_v = min(max(low_v, param_range[0]), param_range[1])
        high_v = init_param_v + margin
        high_v = min(max(high_v, param_range[0]), param_range[1])
        init_param_v = min(max(low_v, init_param_v), high_v)

        param_dict_update_range[isp_param_name] = [low_v, high_v, init_param_v, param_range[0], param_range[1]]
        cnt += 1
    return param_dict_update_range

def randomSample(param_dict, N, param_info):
    '''
    :param bounds: 参数对应范围(list)
    :param N: 样本数量
    :return: 样本数据
    '''
    result = np.empty([N, len(list(param_dict.keys()))])
    param_name = list(param_dict.keys())
    param_info_name = list(param_info.keys())
    for i in range(N):
        sample = []
        for j in range(result.shape[1]):
            x = random.uniform(param_dict[param_name[j]][0], param_dict[param_name[j]][1])
            if param_name[j] in param_info_name:
                info = param_info[param_name[j]]
                if 'Odd' in info[0]:
                    x = (x // 2)*2 + 1
                if 'Inc' in info[0]:
                    if len(info) == 3 and 'Inc' == info[0]:
                        x = sample[j-1] + random.uniform(info[1], info[2])
                    else:
                        if sample[j-1] > param_dict[param_name[j]][0]:
                            x = random.uniform(sample[j-1], param_dict[param_name[j]][1]) # min(x, sample[j-1])
                        else:
                            x = random.uniform(param_dict[param_name[j]][0], param_dict[param_name[j]][1]) # min(x, sample[j-1])
                    if 'StrInc' in info[0]:
                        if 'Odd' not in info[0]:
                            if int(x+0.5) <= int(sample[j-1]+0.5):
                                x = sample[j-1] + 1
                        else:
                            x = (x // 2)*2 + 1
                            if int(x+0.5) <= int(sample[j-1]+0.5):
                                x = sample[j-1] + 2
                if 'Dec' in info[0]:
                    if len(info) == 3 and info[0] == 'Dec':
                        x = sample[j-1] - random.uniform(info[1], info[2])
                    else:
                        if sample[j-1] < param_dict[param_name[j]][1]:
                            x = random.uniform(param_dict[param_name[j]][0], sample[j-1]) # min(x, sample[j-1])
                        else:
                            x = random.uniform(param_dict[param_name[j]][0], param_dict[param_name[j]][1]) # min(x, sample[j-1])
                    if info[0] == 'StrDec':
                        x = min(x, param_dict[param_name[j]][2])
                x = max(min(x, param_dict[param_name[j]][-1]), param_dict[param_name[j]][-2])
            sample.append(x)
        result[i] = np.array(sample)

    # 更新参数字典
    param_min = np.min(result, axis=0)
    param_max = np.max(result, axis=0)
    for i in range(result.shape[1]):
        param_dict[param_name[i]][0] = int(param_min[i]+0.5) if param_min[i]>0 else int(param_min[i]-0.5)
        param_dict[param_name[i]][1] = int(param_max[i]+0.5) if param_max[i]>0 else int(param_max[i]-0.5)
    return result, param_dict

def validParams(param_dict, value):
    isp_param_name = list(param_dict.keys())
    for i in range(len(value)):
        x = int(value[i]+0.5) if value[i]>0 else int(value[i]-0.5)
        if x < param_dict[isp_param_name[i]][0] or x > param_dict[isp_param_name[i]][1]:
            raise Exception(isp_param_name[i]+'参数范围越界!')
    return True

def mergeSampleResult(param_dict_opt, param_dict, result, init_param):
    sample_result = np.empty([result.shape[0], len(list(param_dict.keys()))])
    i = 0
    j = 0
    for isp_param_name in list(param_dict.keys()):
        if isp_param_name in list(param_dict_opt.keys()):
            sample_result[:, i:i+1] = result[:, j:j+1]
            j+=1
        else:
            sample_result[:, i] = init_param[i]
        i+=1
    return sample_result

def mergeSampleResultCollect(param_dict, param_dict_info, result):
    def getFullCurve(result_curve, sample_nums, nums):
        index = [0]
        margin = nums // (sample_nums-1)
        for i in range(sample_nums - 2):
            index.append((i+1)*margin)
        index.append(nums-1)
        result_curve = np.array([np.interp(np.arange(nums), index, result_curve[i,:]) for i in range(result_curve.shape[0])])
        return result_curve

    i = 0
    for isp_param_name in list(param_dict.keys()):
        if isp_param_name in list(param_dict_info.keys()) and 'Trans' in param_dict_info[isp_param_name][0]:
            result[:, i:i+1] = np.where(result[:, i:i+1]>=0, result[:, i:i+1], result[:, i:i+1]+param_dict_info[isp_param_name][-1])
        i += 1

    result_final = []
    pre_isp_param_name = ''
    for i in range(len(list(param_dict.keys()))):
        isp_param_name = list(param_dict.keys())[i]
        if isp_param_name in list(param_dict_info.keys()) and 'Curve' in param_dict_info[isp_param_name][0]:
            if isp_param_name.split('.')[-1].split('_')[0] == pre_isp_param_name.split('.')[-1].split('_')[0]:
                pre_isp_param_name = isp_param_name
                continue
            result_curve = getFullCurve(result[:, i:i+param_dict_info[isp_param_name][1]].copy(), param_dict_info[isp_param_name][1], param_dict_info[isp_param_name][2])
            result_final.append(result_curve)
        else:
            result_final.append(result[:, i:i+1])
        pre_isp_param_name = isp_param_name
    return np.concatenate(result_final, axis=1)

def transferInitParam(init_param_value_list, param_dict_unfold, param_info_unfold):
    i = 0
    for isp_param_name in list(param_dict_unfold.keys()):
        if isp_param_name in list(param_info_unfold.keys()) and 'Trans' in param_info_unfold[isp_param_name][0]:
            if init_param_value_list[i] > param_info_unfold[isp_param_name][1]:
                init_param_value_list[i] -= param_info_unfold[isp_param_name][2]
        i += 1
    return init_param_value_list

def writeSampleTxt(param_dict_opt, param_dict, result, init_param, txtname='', param_loop=1):
    result_update = mergeSampleResult(param_dict_opt, param_dict, result.copy(), init_param)
    with open(txtname, 'a') as f:
        for i in range(result_update.shape[0]):
            for j in range(param_loop):
                value = []
                for x in result_update[i]:
                    value.append(int(x+0.5) if x>0 else int(x-0.5))

                validParams(param_dict_opt, result[i])
                value_ = ''
                for v in value:
                    value_ += str(v)
                    value_ += ' '
                f.write(value_[:-1]+'\n')

def writeSampleCollectTxt(param_dict_opt, param_dict, param_dict_info, result, init_param, txtname='', param_loop=1, gain=0):
    result_update = mergeSampleResult(param_dict_opt, param_dict, result.copy(), init_param)
    result_update = mergeSampleResultCollect(param_dict, param_dict_info, result_update)
    with open(txtname, 'a') as f:
        for i in range(result_update.shape[0]):
            for j in range(param_loop):
                value = []
                for x in result_update[i]:
                    value.append(int(x+0.5) if x>0 else int(x-0.5))

                validParams(param_dict_opt, result[i])
                value_ = str(gain)+' '
                for v in value:
                    value_ += str(v)
                    value_ += ' '
                f.write(value_[:-1]+'\n')

def writeOptParamDict(param_dict, txtname, gain, is_first, is_last):
    params_name_list = list(param_dict.keys())
    cnt = 0
    with open(txtname, 'a') as f:
        if is_first:
            f.write('%s\n' % ('def get_params_range(gain):'))
        f.write('\t%s\n' % ('param_dict_%ddB={'%(gain)))
        for params_name in params_name_list:
            if '/' not in params_name:
                f.write('\t\t\'%s\':\t [%d, %d, %d, %d, %d],\n' % 
                    (params_name, param_dict[params_name][0], param_dict[params_name][1], 
                    param_dict[params_name][2], param_dict[params_name][3], param_dict[params_name][4]))
                cnt += 1
            else:
                for k in range(int(params_name.split('/')[-1])):
                    f.write('\t\t\'%s/%d\':\t [%d, %d, %d, %d, %d],\n' % 
                    (params_name.split('/')[0], k+1, param_dict[params_name][0], param_dict[params_name][1], 
                    param_dict[params_name][2], param_dict[params_name][3], param_dict[params_name][4]))
                    cnt += 1
        f.write('\t%s\n' % ('}'))
        if is_last:
            f.write('\t%s\n' % ('return locals()[\'param_dict_%sdB\'%str(gain)]'))

def writeAllParamsDict(param_dict, txtname, gain, is_first, is_last):
    cnt = 0
    with open(txtname, 'a') as f:
        if is_first:
            f.write('%s\n' % ('def get_params_range(gain):'))
        f.write('\t%s\n' % ('param_dict_%ddB={'%(gain)))
        for params_name in param_dict.keys():
            if '/' not in params_name:
                f.write('\t\t\'%s\':\t [%d, %d, %d],\n' % 
                    (params_name, param_dict[params_name][0], param_dict[params_name][1], param_dict[params_name][2]))
                cnt += 1
            else:
                for k in range(int(params_name.split('/')[-1])):
                    f.write('\t\t\'%s/%d\':\t [%d, %d, %d],\n' % 
                    (params_name.split('/')[0], k+1, param_dict[params_name][0], param_dict[params_name][1], param_dict[params_name][2]))
                    cnt += 1
        f.write('\t%s\n' % ('}'))
        if is_last:
            f.write('\t%s\n' % ('return locals()[\'param_dict_%sdB\'%str(gain)]'))

def mergeParam(predict_param, init_param_value_list, param_dict_opt_unfold, param_dict_unfold, param_info_unfold):
    if len(predict_param) == 0:
        return init_param_value_list
    else:
        i = 0
        j = 0
        predict_param_new = []
        for isp_param_name in list(param_dict_unfold.keys()):
            low  = param_dict_unfold[isp_param_name][-2]
            high = param_dict_unfold[isp_param_name][-1]
            if isp_param_name in (param_dict_opt_unfold.keys()):
                predict_param_new.append(max(min(predict_param[i], high), low))
                i += 1
            else:
                if isp_param_name in param_info_unfold.keys() and 'Trans' in param_info_unfold[isp_param_name][0]:
                    predict_param_new.append(init_param_value_list[j])
                else:
                    predict_param_new.append(max(min(init_param_value_list[j], high), low))
            j += 1
        if i!= len(predict_param) or j !=len(init_param_value_list):
            raise Exception('Error!')
        return predict_param_new

def changeStrParamValue(predict_param, param_dict_unfold, param_info_unfold):
    index = 0
    for isp_param_name in param_dict_unfold.keys():
        if isp_param_name in param_info_unfold.keys() and 'StrInc' in param_info_unfold[isp_param_name][0] and (predict_param[index]-1)//2 == (predict_param[index-1]-1)//2:
            print(isp_param_name, predict_param[index-1], predict_param[index])
            predict_param[index-1] = predict_param[index-1] - 1
            print(isp_param_name, predict_param[index-1], predict_param[index])
        index += 1
    return predict_param

def read_xml(in_path):
    '''读取并解析xml文件
       in_path: xml路径
       return: ElementTree'''
    tree = ElementTree()
    tree.parse(in_path)
    return tree
 
def write_xml(tree, out_path):
    '''将xml文件写出
       tree: xml树
       out_path: 写出路径'''
    tree.write(out_path, encoding="UTF-8",xml_declaration=True)

def isUseInfo(isp_param_name, param_dict):
    for name in param_dict.keys():
        if isp_param_name.split('/')[0] == name.split('/')[0]:
            return param_dict[name]
    return None

def if_match(node, kv_map):
    '''判断某个节点是否包含所有传入参数属性
       node: 节点
       kv_map: 属性及属性值组成的map'''
    for key in kv_map:
        if node.get(key) != kv_map.get(key):
            return False
    return True
 
def find_nodes(tree, path):
    '''查找某个路径匹配的所有节点
       tree: xml树
       path: 节点路径'''
    return tree.findall(path)
 
def get_node_by_keyvalue(nodelist, kv_map):
    '''根据属性及属性值定位符合的节点，返回节点
       nodelist: 节点列表
       kv_map: 匹配属性及属性值map'''
    result_nodes = []
    for node in nodelist:
        if if_match(node, kv_map):
            result_nodes.append(node)
    return result_nodes

def transferParamValue(value, info, value_range):
    def getFullCurve(result_curve, sample_nums, nums):
        index = [0]
        margin = nums // (sample_nums-1)
        for i in range(sample_nums - 2):
            index.append((i+1)*margin)
        index.append(nums-1)
        result_curve = np.array(np.interp(np.arange(nums), index, result_curve))
        return result_curve

    global pre_value
    if isinstance(value, int):
        value = [value]
    if 'Trans' in info[0]:
        value = [x+info[2] if x<0 else x for x in value]
    if 'Odd' in info[0]:
        if 'StrInc' in info[0]:
            value = [min(max(((x-1) // 2)*2 + 1, value_range[0]), value_range[1]) for x in value]
            if value[0] == pre_value: value[0] += 2
        else:
            value = [min(max(((x-1) // 2)*2 + 1, value_range[0]), value_range[1]) for x in value]
            pre_value = value[0]
    if 'Curve' in info[0]:
        value = getFullCurve(np.array(value), info[1], info[2]).tolist()
        value = [int(x) for x in value]
    return value

def getInitParamsValue(xml_path, gain, params_dict):
    tree = read_xml(xml_path)
    nodes = find_nodes(tree, "DEFINITIONS/STRUCT_DEF/STRUCT/MEMBER")
    gain_index = int(gain // 6)
    init_param_value_list = []
    
    is_tdnr = False
    for isp_param_name in params_dict.keys():
        is_tdnr = False if isp_param_name.split('.')[0] != 'cnviTdnrAutoAttr_t' else True
        isp_param_name_raw = isp_param_name.split('/')[0]
        result_nodes = get_node_by_keyvalue(nodes, {'TYPE': isp_param_name_raw.split('.')[0]})
        if len(result_nodes)==0: result_nodes = get_node_by_keyvalue(nodes, {'ID': isp_param_name_raw.split('.')[0]})
        if len(result_nodes)!=1 : raise Exception(isp_param_name+' 节点错误!')

        isp_param_name_raw_list = isp_param_name_raw.split('.')
        if is_tdnr:
            isp_param_name_raw_list.insert(1, 'stTdnrParam')
            isp_param_name_raw_list.insert(2, 'ARRITEM')

        if len(isp_param_name_raw_list) != 1:
            for name in isp_param_name_raw_list[1:-1]:
                if len(result_nodes) > 1 and is_tdnr:
                    result_nodes = find_nodes(result_nodes[gain_index], name)
                else:
                    result_nodes = find_nodes(result_nodes[0], name)

            result_nodes = find_nodes(result_nodes[0], isp_param_name_raw_list[-1])

        if len(result_nodes)!=1 : raise Exception(isp_param_name+' 节点错误!')
        param_value = [int(x) for x in result_nodes[0].text.split(',')]
        count = [] if 'COUNT' not in result_nodes[0].attrib else [int(x) for x in result_nodes[0].attrib['COUNT'].split(',')]
        if '/' not in isp_param_name:
            if is_tdnr:
                init_param_value_list += param_value
            else:
                if len(count) == 2 and count[1] == 2:
                    try:
                        init_param_value_list.append(param_value[gain_index*2+1])
                    except:
                        init_param_value_list.append(param_value[0*2+1])
                else:
                    init_param_value_list += param_value
                    print(isp_param_name + ' COUNT不等于2!')
                    # raise Exception(isp_param_name+' COUNT错误!')
        else:
            if '_' in isp_param_name.split('/')[-1]:
                if is_tdnr:
                    nums = int(isp_param_name.split('/')[-1].split('_')[-1])
                    sample_nums = int(isp_param_name.split('/')[-1].split('_')[1]) - int(isp_param_name.split('/')[-1].split('_')[0])
                    if sample_nums > 2:
                        param_value_sample = [param_value[0]]
                        for i in range(sample_nums-2):
                            index = (i+1)*(nums//(sample_nums-1))
                            param_value_sample.append(param_value[index])
                        param_value_sample.append(param_value[-1])
                    else:
                        param_value_sample = param_value[int(isp_param_name.split('/')[-1].split('_')[0]): int(isp_param_name.split('/')[-1].split('_')[1])]
                    init_param_value_list += param_value_sample
                else:
                    raise Exception(isp_param_name+' 参数错误!')
            else:
                if is_tdnr:
                    init_param_value_list += param_value
                else:
                    raise Exception(isp_param_name+' 参数错误!')

    return init_param_value_list

def findISPCParam(isp_param_name_c, isp_c_file, param_type):
    line_index = 0
    if param_type == 'Person':
        for line in isp_c_file:
            if isp_param_name_c in line and ('static' in line or 'int' in line):
                if isp_param_name_c == 'contrast_linear' and 'IPC2856' not in isp_c_file[line_index-2]:
                    line_index += 1
                    continue
                return line, line_index
            line_index += 1
    elif param_type == 'Car':
        if isp_param_name_c == 'contrast_linear_car':
                isp_param_name_c = 'contrast_linear'
        for line in isp_c_file:
            if isp_param_name_c in line and ('static' in line or 'int' in line):
                if isp_param_name_c == 'contrast_linear' and ('IPC2856' not in isp_c_file[line_index-2] or 'car' not in isp_c_file[line_index-2]):
                    line_index += 1
                    continue
                return line, line_index
            line_index += 1
    elif param_type == 'DCG':
        if isp_param_name_c == 'contrast_linear_DCG':
                isp_param_name_c = 'contrast_wdr'
        for line in isp_c_file:
            if isp_param_name_c in line and ('static' in line or 'int' in line):
                if isp_param_name_c == 'contrast_wdr' and 'IPC2856' not in isp_c_file[line_index-3]:
                    line_index += 1
                    continue
                return line, line_index
            line_index += 1
    return None, -1

def readISPCFile(isp_c_file_path):
    isp_c_file = []
    with open(isp_c_file_path, "r", encoding='gb18030') as f:
        for line in f.readlines():
            isp_c_file.append(line)
    return isp_c_file

def transValListToStr(isp_param_name_c_line_val):
    isp_param_name_c_line_val_str = ''
    for val in isp_param_name_c_line_val[:-1]:
        if isinstance(val, str):
            isp_param_name_c_line_val_str += val+','
        elif isinstance(val, int):
            isp_param_name_c_line_val_str += str(val)+','
    if isinstance(isp_param_name_c_line_val[-1], str):
        isp_param_name_c_line_val_str += isp_param_name_c_line_val[-1]
    elif isinstance(isp_param_name_c_line_val[-1], int):
        isp_param_name_c_line_val_str += str(isp_param_name_c_line_val[-1])
    return isp_param_name_c_line_val_str

def writeISPCFile(isp_c_file, save_path):
    with open(save_path, 'w') as f:
        for line in isp_c_file:
            f.write(line)
    f.close()